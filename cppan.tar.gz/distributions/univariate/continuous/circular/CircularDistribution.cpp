#include "CircularDistribution.h"

CircularDistribution::CircularDistribution(double location)
{
    SetLocation(location);
}

void CircularDistribution::SetLocation(double location)
{
    loc = location;
}
