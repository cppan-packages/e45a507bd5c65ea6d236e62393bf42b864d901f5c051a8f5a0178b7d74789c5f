#include "DiscreteBivariateDistribution.h"
#include "../univariate/discrete/BinomialRand.h"

template class DiscreteBivariateDistribution<BinomialRand, BinomialRand>;
